﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace task13
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<Phone> phones;
        Phone tempPhone; 
        public MainWindow()
        {
            InitializeComponent();
            phones = new List<Phone>
            {
                new Phone { Company = "Apple", Title = "iPhone 10", Price = 58000},
                new Phone { Company = "Xiaomi", Title = "Redmi Note 10S", Price = 28000 },
                new Phone { Company = "Apple", Title = "iPhone 12 Pro Max Super Idol", Price = 158000},
                new Phone { Company = "Nokia", Title = "3310", Price = 800}
            };
            mainListBox.ItemsSource = phones;
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        {
            try{
                if(Convert.ToDecimal(priceView.Text) < 0 || companyView.Text == String.Empty || titleView.Text == String.Empty)
                {
                    throw new Exception("Ошибка");
                }
                phones.Add(new Phone
                {
                    Company = companyView.Text,
                    Title = titleView.Text,
                    Price = Convert.ToDecimal(priceView.Text)
                });
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            mainListBox.ItemsSource = null;
            mainListBox.ItemsSource = phones;
        }
        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            tempPhone = mainListBox.SelectedItem as Phone;
            if (tempPhone != null)
            {
                titleView.Text = tempPhone.Title;
                companyView.Text = tempPhone.Company;
                priceView.Text = tempPhone.Price.ToString();

                mainListBox.IsEnabled = false;
                addButtonView.IsEnabled = false;
                editButtonView.IsEnabled = false;
                deleteButtonView.IsEnabled = false;

                saveEditButtonView.Visibility = Visibility.Visible;
                cancelEditButtonView.Visibility = Visibility.Visible;
            }
            mainListBox.ItemsSource = null;
            mainListBox.ItemsSource = phones;
        }
        private void EndEditing()
        {
            titleView.Text = String.Empty;
            companyView.Text = String.Empty;
            priceView.Text = String.Empty;
            mainListBox.IsEnabled = true;
            addButtonView.IsEnabled = true;
            editButtonView.IsEnabled = true;
            deleteButtonView.IsEnabled = true;

            saveEditButtonView.Visibility = Visibility.Hidden;
            cancelEditButtonView.Visibility = Visibility.Hidden;
        }
        private void cancelEditButtonView_Click(object sender, RoutedEventArgs e) => EndEditing();
        private void saveEditButtonView_Click(object sender, RoutedEventArgs e)
        {
            try{
                if(Convert.ToDecimal(priceView.Text) < 0 || companyView.Text == String.Empty || titleView.Text == String.Empty)
                {
                    throw new Exception("Ошибка");
                }
                tempPhone.Company = companyView.Text;
                tempPhone.Title = titleView.Text;
                tempPhone.Price = Convert.ToDecimal(priceView.Text);
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            mainListBox.ItemsSource = null;
            mainListBox.ItemsSource = phones;
            EndEditing();      
        }
        private void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                phones.Remove(mainListBox.SelectedItem as Phone);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            mainListBox.ItemsSource = null;
            mainListBox.ItemsSource = phones;
        }

        private void saveEditButtonView_Click_1(object sender, RoutedEventArgs e)
        {

        }
    }
}
